require("freedesktop.utils")
require("freedesktop.menu")
require("freedesktop.desktop")

module("freedesktop")
