This is [awesome-freedesktop](https://github.com/terceiro/awesome-freedesktop),
adapted to work within [awesome-copycats](https://github.com/copycat-killer/awesome-copycats).

License
=======

Copyright © 2009-2011 Antonio Terceiro <terceiro@softwarelivre.org>

This code is licensed under the same terms as Awesome WM itself: [GNU
GPLv2](http://www.gnu.org/licenses/gpl-2.0.txt).
