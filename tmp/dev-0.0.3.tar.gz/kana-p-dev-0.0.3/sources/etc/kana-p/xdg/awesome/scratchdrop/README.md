This is the `drop` section of [scratchpad](http://awesome.naquadah.org/wiki/Scratchpad_manager).

I cutted out the rest because I don't use it.
